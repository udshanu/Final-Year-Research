﻿namespace Aforge_Part1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.processingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grayScaleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.edgeDetectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cropToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.picCropWatermark = new System.Windows.Forms.PictureBox();
            this.picCropNumber = new System.Windows.Forms.PictureBox();
            this.picCropUv = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.picCropLines = new System.Windows.Forms.PictureBox();
            this.picCropBlindDots = new System.Windows.Forms.PictureBox();
            this.picCropButterfly = new System.Windows.Forms.PictureBox();
            this.picCropSriLanka = new System.Windows.Forms.PictureBox();
            this.picCropNoteAmount = new System.Windows.Forms.PictureBox();
            this.picCropStone = new System.Windows.Forms.PictureBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCapture = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.picVideo = new System.Windows.Forms.PictureBox();
            this.picImage = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.picGrayScale = new System.Windows.Forms.PictureBox();
            this.picOriginal = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCropWatermark)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCropNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCropUv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCropLines)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCropBlindDots)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCropButterfly)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCropSriLanka)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCropNoteAmount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCropStone)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picVideo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picImage)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picGrayScale)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOriginal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.processingToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1354, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // processingToolStripMenuItem
            // 
            this.processingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.grayScaleToolStripMenuItem,
            this.edgeDetectionToolStripMenuItem,
            this.cropToolStripMenuItem});
            this.processingToolStripMenuItem.Name = "processingToolStripMenuItem";
            this.processingToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.processingToolStripMenuItem.Text = "Processing";
            // 
            // grayScaleToolStripMenuItem
            // 
            this.grayScaleToolStripMenuItem.Name = "grayScaleToolStripMenuItem";
            this.grayScaleToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.grayScaleToolStripMenuItem.Text = "GrayScale";
            this.grayScaleToolStripMenuItem.Click += new System.EventHandler(this.grayScaleToolStripMenuItem_Click);
            // 
            // edgeDetectionToolStripMenuItem
            // 
            this.edgeDetectionToolStripMenuItem.Name = "edgeDetectionToolStripMenuItem";
            this.edgeDetectionToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.edgeDetectionToolStripMenuItem.Text = "Edge Detection";
            this.edgeDetectionToolStripMenuItem.Click += new System.EventHandler(this.edgeDetectionToolStripMenuItem_Click);
            // 
            // cropToolStripMenuItem
            // 
            this.cropToolStripMenuItem.Name = "cropToolStripMenuItem";
            this.cropToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.cropToolStripMenuItem.Text = "Crop";
            this.cropToolStripMenuItem.Click += new System.EventHandler(this.cropToolStripMenuItem_Click);
            // 
            // picCropWatermark
            // 
            this.picCropWatermark.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCropWatermark.Location = new System.Drawing.Point(977, 27);
            this.picCropWatermark.Name = "picCropWatermark";
            this.picCropWatermark.Size = new System.Drawing.Size(121, 115);
            this.picCropWatermark.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picCropWatermark.TabIndex = 5;
            this.picCropWatermark.TabStop = false;
            // 
            // picCropNumber
            // 
            this.picCropNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCropNumber.Location = new System.Drawing.Point(1152, 27);
            this.picCropNumber.Name = "picCropNumber";
            this.picCropNumber.Size = new System.Drawing.Size(85, 200);
            this.picCropNumber.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picCropNumber.TabIndex = 6;
            this.picCropNumber.TabStop = false;
            // 
            // picCropUv
            // 
            this.picCropUv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCropUv.Location = new System.Drawing.Point(841, 27);
            this.picCropUv.Name = "picCropUv";
            this.picCropUv.Size = new System.Drawing.Size(130, 124);
            this.picCropUv.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picCropUv.TabIndex = 7;
            this.picCropUv.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // picCropLines
            // 
            this.picCropLines.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCropLines.Location = new System.Drawing.Point(1116, 27);
            this.picCropLines.Name = "picCropLines";
            this.picCropLines.Size = new System.Drawing.Size(30, 146);
            this.picCropLines.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picCropLines.TabIndex = 14;
            this.picCropLines.TabStop = false;
            // 
            // picCropBlindDots
            // 
            this.picCropBlindDots.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCropBlindDots.Location = new System.Drawing.Point(1258, 27);
            this.picCropBlindDots.Name = "picCropBlindDots";
            this.picCropBlindDots.Size = new System.Drawing.Size(33, 110);
            this.picCropBlindDots.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picCropBlindDots.TabIndex = 13;
            this.picCropBlindDots.TabStop = false;
            // 
            // picCropButterfly
            // 
            this.picCropButterfly.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCropButterfly.Location = new System.Drawing.Point(665, 157);
            this.picCropButterfly.Name = "picCropButterfly";
            this.picCropButterfly.Size = new System.Drawing.Size(86, 84);
            this.picCropButterfly.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picCropButterfly.TabIndex = 12;
            this.picCropButterfly.TabStop = false;
            // 
            // picCropSriLanka
            // 
            this.picCropSriLanka.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCropSriLanka.Location = new System.Drawing.Point(757, 157);
            this.picCropSriLanka.Name = "picCropSriLanka";
            this.picCropSriLanka.Size = new System.Drawing.Size(95, 76);
            this.picCropSriLanka.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picCropSriLanka.TabIndex = 11;
            this.picCropSriLanka.TabStop = false;
            // 
            // picCropNoteAmount
            // 
            this.picCropNoteAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCropNoteAmount.Location = new System.Drawing.Point(858, 157);
            this.picCropNoteAmount.Name = "picCropNoteAmount";
            this.picCropNoteAmount.Size = new System.Drawing.Size(171, 113);
            this.picCropNoteAmount.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picCropNoteAmount.TabIndex = 10;
            this.picCropNoteAmount.TabStop = false;
            // 
            // picCropStone
            // 
            this.picCropStone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCropStone.Location = new System.Drawing.Point(1116, 233);
            this.picCropStone.Name = "picCropStone";
            this.picCropStone.Size = new System.Drawing.Size(195, 154);
            this.picCropStone.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picCropStone.TabIndex = 8;
            this.picCropStone.TabStop = false;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(408, 27);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCapture
            // 
            this.btnCapture.Location = new System.Drawing.Point(327, 27);
            this.btnCapture.Name = "btnCapture";
            this.btnCapture.Size = new System.Drawing.Size(75, 23);
            this.btnCapture.TabIndex = 11;
            this.btnCapture.Text = "Capture";
            this.btnCapture.UseVisualStyleBackColor = true;
            this.btnCapture.Click += new System.EventHandler(this.btnCapture_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(84, 27);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 10;
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(3, 27);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 9;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // picVideo
            // 
            this.picVideo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picVideo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picVideo.Location = new System.Drawing.Point(3, 3);
            this.picVideo.Name = "picVideo";
            this.picVideo.Size = new System.Drawing.Size(234, 181);
            this.picVideo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picVideo.TabIndex = 0;
            this.picVideo.TabStop = false;
            // 
            // picImage
            // 
            this.picImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picImage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picImage.Location = new System.Drawing.Point(243, 3);
            this.picImage.Name = "picImage";
            this.picImage.Size = new System.Drawing.Size(234, 181);
            this.picImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picImage.TabIndex = 1;
            this.picImage.TabStop = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.picVideo, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.picImage, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 54);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(480, 187);
            this.tableLayoutPanel2.TabIndex = 13;
            // 
            // picGrayScale
            // 
            this.picGrayScale.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picGrayScale.Location = new System.Drawing.Point(665, 27);
            this.picGrayScale.Name = "picGrayScale";
            this.picGrayScale.Size = new System.Drawing.Size(170, 124);
            this.picGrayScale.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picGrayScale.TabIndex = 1;
            this.picGrayScale.TabStop = false;
            // 
            // picOriginal
            // 
            this.picOriginal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picOriginal.Location = new System.Drawing.Point(489, 27);
            this.picOriginal.Name = "picOriginal";
            this.picOriginal.Size = new System.Drawing.Size(170, 124);
            this.picOriginal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picOriginal.TabIndex = 0;
            this.picOriginal.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(3, 274);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(171, 113);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(360, 274);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(171, 113);
            this.pictureBox2.TabIndex = 16;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Location = new System.Drawing.Point(537, 274);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(171, 113);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 17;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox4.Location = new System.Drawing.Point(714, 274);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(171, 113);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 18;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5.Location = new System.Drawing.Point(891, 274);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(171, 113);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 19;
            this.pictureBox5.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1354, 663);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.picCropStone);
            this.Controls.Add(this.picCropNoteAmount);
            this.Controls.Add(this.picCropSriLanka);
            this.Controls.Add(this.picCropButterfly);
            this.Controls.Add(this.picCropBlindDots);
            this.Controls.Add(this.picCropLines);
            this.Controls.Add(this.picOriginal);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.picGrayScale);
            this.Controls.Add(this.picCropNumber);
            this.Controls.Add(this.btnCapture);
            this.Controls.Add(this.picCropWatermark);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.picCropUv);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCropWatermark)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCropNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCropUv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCropLines)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCropBlindDots)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCropButterfly)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCropSriLanka)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCropNoteAmount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCropStone)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picVideo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picImage)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picGrayScale)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOriginal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem processingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem grayScaleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem edgeDetectionToolStripMenuItem;
        private System.Windows.Forms.PictureBox picCropWatermark;
        private System.Windows.Forms.ToolStripMenuItem cropToolStripMenuItem;
        private System.Windows.Forms.PictureBox picCropNumber;
        private System.Windows.Forms.PictureBox picCropUv;
        private System.Windows.Forms.PictureBox picCropStone;
        private System.Windows.Forms.PictureBox picCropNoteAmount;
        private System.Windows.Forms.PictureBox picCropSriLanka;
        private System.Windows.Forms.PictureBox picCropButterfly;
        private System.Windows.Forms.PictureBox picCropBlindDots;
        private System.Windows.Forms.PictureBox picCropLines;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCapture;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.PictureBox picVideo;
        private System.Windows.Forms.PictureBox picImage;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.PictureBox picGrayScale;
        private System.Windows.Forms.PictureBox picOriginal;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
    }
}

