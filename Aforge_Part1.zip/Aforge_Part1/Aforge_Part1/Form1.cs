﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using AForge;
using AForge.Imaging;
using AForge.Imaging.ColorReduction;
using AForge.Imaging.ComplexFilters;
using AForge.Imaging.Filters;
using AForge.Video;
using AForge.Video.DirectShow;
using System.Drawing.Imaging;

namespace Aforge_Part1
{
    public partial class Form1 : Form
    {
        string filePath;
        Bitmap grayImage;
        Bitmap grayImageSerial;
        Bitmap grayImageNoteAmount;
        GrayscaleBT709 gray = new GrayscaleBT709();

        private FilterInfoCollection CaptureDevice;
        private VideoCaptureDevice FinalFrame;

        public Form1()
        {
            InitializeComponent();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(openFileDialog1.ShowDialog()==System.Windows.Forms.DialogResult.OK)
            {
                filePath = openFileDialog1.FileName;
                picOriginal.Image = (Bitmap)System.Drawing.Image.FromFile(filePath);
            }
        }

        private void grayScaleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //gray = new GrayscaleBT709();
            //grayImage = gray.Apply((Bitmap)picOriginal.Image);
            grayImage = gray.Apply((Bitmap)picImage.Image);
            picGrayScale.Image = grayImage;  
        }

        private void edgeDetectionToolStripMenuItem_Click(object sender, EventArgs e)
        {

            //gray = new GrayscaleBT709();
            //grayImage = gray.Apply((Bitmap)picOriginal.Image);
            grayImage = gray.Apply((Bitmap)picImage.Image);
            picGrayScale.Image = grayImage;

            //// create canny filter
            //CannyEdgeDetector cannyFilter = new CannyEdgeDetector();
            //// You can use ApplyInPlace() to modify the input image or use 
            ////Apply() to make a new copy of the image with the filter applied...
            ////cannyFilter.ApplyInPlace(grayImage);
            //Bitmap cannyImage = cannyFilter.Apply(grayImage);
            //picEdgeCanney.Image = cannyImage;

            //// create homogenity filter
            //HomogenityEdgeDetector homoFilter = new HomogenityEdgeDetector();
            //// apply the filter
            ////homoFilter.ApplyInPlace(grayImage);
            //Bitmap homoImage = homoFilter.Apply(grayImage);
            //picEdgeHomoginiti.Image = homoImage;

            //// create difference filter
            //DifferenceEdgeDetector diffFilter = new DifferenceEdgeDetector();
            //// apply the filter
            ////diffFilter.ApplyInPlace(grayImage);
            //Bitmap diffImage = diffFilter.Apply(grayImage);
            //picEdgeHomoginiti.Image = diffImage;


            //// create sobel filter
            //SobelEdgeDetector sobelFilter = new SobelEdgeDetector();
            //// apply the filter
            ////sobelFilter.ApplyInPlace(grayImage);
            //Bitmap sobleImage = sobelFilter.Apply(grayImage);
            //picEdgeDifference.Image = sobleImage;
        }

        private void cropToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //GrayscaleBT709 gray = new GrayscaleBT709();
            //grayImage = gray.Apply((Bitmap)picOriginal.Image);
            grayImage = gray.Apply((Bitmap)picOriginal.Image);
            picGrayScale.Image = grayImage;


            /////--Water Mark--////
            // create filter
            Crop cropWaterMark = new Crop(new Rectangle(40, 233, 120, 115));
            // apply the filter
            Bitmap cropedImageWaterMark = cropWaterMark.Apply(grayImage);
            picCropWatermark.Image = cropedImageWaterMark;

            ///--UV Image--///
            // create filter
            Crop cropUv = new Crop(new Rectangle(346, 286, 100, 100));
            // apply the filter
            Bitmap cropedImageUv = cropUv.Apply((Bitmap)picOriginal.Image);
            picCropUv.Image = cropedImageUv;

            //---Serial Number---////
            // create filter
            Crop cropSerial = new Crop(new Rectangle(460, 195, 45, 175));
            // apply the filter
            Bitmap cropedImageSerial = cropSerial.Apply((Bitmap)picOriginal.Image);
            picCropNumber.Image = cropedImageSerial;

            //---Lines---////
            // create filter
            Crop cropLines = new Crop(new Rectangle(610, 230, 20, 110));
            // apply the filter
            Bitmap cropedImageLines = cropLines.Apply((Bitmap)picOriginal.Image);
            picCropLines.Image = cropedImageLines;

            /////--Blind Dots--////
            // create filter
            Crop cropBlindDots = new Crop(new Rectangle(15, 195, 30, 100));
            // apply the filter
            Bitmap cropedImageBlindDots = cropBlindDots.Apply((Bitmap)picOriginal.Image);
            picCropBlindDots.Image = cropedImageBlindDots;


            /////--Butterfly--////
            // create filter
            Crop cropButterfly = new Crop(new Rectangle(25, 310, 100, 100));
            // apply the filter
            Bitmap cropedImageButterfly = cropButterfly.Apply((Bitmap)picOriginal.Image);
            picCropButterfly.Image = cropedImageButterfly;

            ///--SriLanka--///
            // create filter
            Crop cropSriLanka = new Crop(new Rectangle(525, 140, 65, 50));
            // apply the filter
            Bitmap cropedImageSriLanka = cropSriLanka.Apply((Bitmap)picOriginal.Image);
            picCropSriLanka.Image = cropedImageSriLanka;


            //////////---- OtsuThreshold----/////////////////
            //// create filter
            //OtsuThreshold otsufilter1 = new OtsuThreshold();
            //// apply the filter
            //Bitmap otsuImage1 = otsufilter1.Apply(newImage1);
            //pictureBox5.Image = otsuImage1;

            ////---Serial Number---////
            //// create filter
            //Crop cropSerial = new Crop(new Rectangle(1650, 530, 150, 530));
            //// apply the filter
            //Bitmap cropedImageSerial = cropSerial.Apply(grayImage);
            //picCropNumber.Image = cropedImageSerial;
            

            //////////---- OtsuThreshold----/////////////////
            //// create filter
            //OtsuThreshold otsufilter = new OtsuThreshold();
            //// apply the filter
            //Bitmap otsuImage = otsufilter.Apply(cropedImageSerial);
            //pictureBox1.Image = otsuImage;


            ////---Cropping First Number---////
            //// create filter
            //Crop cropFirstNumber = new Crop(new Rectangle(0, 0, 100, 40));
            //// apply the filter
            //Bitmap cropedImageFirstNum = cropFirstNumber.Apply(otsuImage);
            ////pictureBox2.Image = cropedImageFirstNum;


            ////---Close---///
            //// create filter
            //Closing closeFilter = new Closing();
            //// apply the filter
            //Bitmap FirstNumClose = closeFilter.Apply(cropedImageFirstNum);
            //////pictureBox3.Image = FirstNumClose;

            ////----Erosion First Number---///
            //// create filter
            //Erosion erosionFilterFirstNum = new Erosion();
            //// apply the filter
            //Bitmap erosionImageFirstNum = erosionFilterFirstNum.Apply(FirstNumClose);
            ////pictureBox4.Image = erosionImageFirstNum;

            ////---Open---//
            //// create filter
            //Opening openFilter = new Opening();
            //// apply the filter
            //Bitmap FirstNumOpen = openFilter.Apply(erosionImageFirstNum);
            ////pictureBox5.Image = FirstNumOpen;

            ////---Close---///
            //// create filter
            //Closing closeFilter1 = new Closing();
            //// apply the filter
            //Bitmap FirstNumClose1 = closeFilter1.Apply(FirstNumOpen);
            ////pictureBox6.Image = FirstNumClose1;


            ////--Median Filter---///
            //// create filter
            //Median MedianFilter = new Median();
            //// apply the filter
            //Bitmap FirstNumMedian = MedianFilter.Apply(FirstNumClose1);
            //pictureBox2.Image = FirstNumMedian;


            //// create the filter
            //BradleyLocalThresholding filterBrad = new BradleyLocalThresholding();
            //// apply the filter
            //Bitmap FirstNumBrad = filterBrad.Apply(otsuImage);
            ////pictureBox3.Image = FirstNumBrad;

            ////--Median Filter---///
            //// create filter
            //Median MedianFilter1 = new Median();
            //// apply the filter
            //Bitmap FirstNumMedian1 = MedianFilter1.Apply(FirstNumBrad);
            //pictureBox3.Image = FirstNumMedian1;
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CaptureDevice = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            foreach (FilterInfo Device in CaptureDevice)
            {
                comboBox1.Items.Add(Device.Name);
            }
            comboBox1.SelectedIndex = 1;
            FinalFrame = new VideoCaptureDevice();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            FinalFrame = new VideoCaptureDevice(CaptureDevice[comboBox1.SelectedIndex].MonikerString);
            FinalFrame.NewFrame += new NewFrameEventHandler(FinalFrame_NewFrame);
            FinalFrame.Start();
        }

        private void FinalFrame_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            picVideo.Image = (Bitmap)eventArgs.Frame.Clone();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (FinalFrame.IsRunning == true)
            {
                FinalFrame.Stop();
            }
        }

        private void btnCapture_Click(object sender, EventArgs e)
        {
            picImage.Image = (Bitmap)picVideo.Image.Clone();

            GrayscaleBT709 gray = new GrayscaleBT709();
            //grayImage = gray.Apply((Bitmap)picOriginal.Image);
            grayImage = gray.Apply((Bitmap)picImage.Image);
            picGrayScale.Image = grayImage; 

            /////--Water Mark--////
            // create filter
            Crop cropWaterMark = new Crop(new Rectangle(30, 223, 130, 125));
            // apply the filter
            Bitmap cropedImageWaterMark = cropWaterMark.Apply(grayImage);
            picCropWatermark.Image = cropedImageWaterMark;

            ///--UV Image--///
            // create filter
            Crop cropUv = new Crop(new Rectangle(336, 276, 120, 120));
            // apply the filter
            Bitmap cropedImageUv = cropUv.Apply((Bitmap)picImage.Image);
            picCropUv.Image = cropedImageUv;

            //---Serial Number---////
            // create filter
            Crop cropSerial = new Crop(new Rectangle(440, 175, 75, 210));
            // apply the filter
            Bitmap cropedImageSerial = cropSerial.Apply((Bitmap)picImage.Image);
            picCropNumber.Image = cropedImageSerial;

            //---Lines---////
            // create filter
            Crop cropLines = new Crop(new Rectangle(610, 230, 20, 110));
            // apply the filter
            Bitmap cropedImageLines = cropLines.Apply((Bitmap)picImage.Image);
            picCropLines.Image = cropedImageLines;

            /////--Blind Dots--////
            // create filter
            Crop cropBlindDots = new Crop(new Rectangle(5, 175, 45, 110));
            // apply the filter
            Bitmap cropedImageBlindDots = cropBlindDots.Apply((Bitmap)picImage.Image);
            picCropBlindDots.Image = cropedImageBlindDots;


            /////--Butterfly--////
            // create filter
            Crop cropButterfly = new Crop(new Rectangle(15, 300, 115, 115));
            // apply the filter
            Bitmap cropedImageButterfly = cropButterfly.Apply((Bitmap)picImage.Image);
            picCropButterfly.Image = cropedImageButterfly;

            ///--SriLanka--///
            // create filter
            Crop cropSriLanka = new Crop(new Rectangle(515, 130, 75, 60));
            // apply the filter
            Bitmap cropedImageSriLanka = cropSriLanka.Apply((Bitmap)picImage.Image);
            picCropSriLanka.Image = cropedImageSriLanka;


            ///--Note Amount--///
            // create filter
            Crop cropNoteAmount = new Crop(new Rectangle(504, 340, 104, 57));
            // apply the filter
            Bitmap cropedImageNoteAmount = cropNoteAmount.Apply((Bitmap)picImage.Image);
            picCropNoteAmount.Image = cropedImageNoteAmount;

            ////////---- Gray Scale Note Amount----/////////////////
            grayImageNoteAmount = gray.Apply(cropedImageNoteAmount);
            //pictureBox1.Image = grayImageSerial;

            // create filter
            HistogramEqualization cs = new HistogramEqualization();
            // process image
            Bitmap abc = cs.Apply(grayImageNoteAmount);
            //pictureBox1.Image = abc;

            ////////---- OtsuThreshold for Note Amount----/////////////////
            // create filter
            OtsuThreshold otsufilter1 = new OtsuThreshold();
            // apply the filter
            Bitmap otsuImageNoteAmount = otsufilter1.Apply(abc);
            //pictureBox2.Image = otsuImageNoteAmount;

            //////---- Opening for Note Amount----/////////////////
             //create filter
            Opening op = new Opening();
            //apply the filter
            Bitmap openImageNoteAmount = op.Apply(otsuImageNoteAmount);
            //pictureBox3.Image = openImageNoteAmount;

            Closing cllll = new Closing();
            //apply the filter
            Bitmap clImageNoteAmount = cllll.Apply(openImageNoteAmount);
            //pictureBox4.Image = clImageNoteAmount;

            // create filter
            Median me = new Median();
            // apply the filter
            Bitmap medianImageNoteAmount = me.Apply(clImageNoteAmount);
            //pictureBox4.Image = medianImageNoteAmount;


            // create filter
            Dilatation ee = new Dilatation();
            // apply the filter
            Bitmap eeImageNoteAmount = ee.Apply(medianImageNoteAmount);
            //Bitmap eeImageNoteAmount1 = ee.Apply(eeImageNoteAmount);
            pictureBox1.Image = eeImageNoteAmount;

            //Crop cropNoteAmountForOcr = new Crop(new Rectangle(20, 10, 93, 51));
            //// apply the filter
            //Bitmap cropedImageNoteAmountForOcr = cropNoteAmountForOcr.Apply(eeImageNoteAmount);
            //pictureBox1.Image = cropedImageNoteAmountForOcr;


            /////--Stone--////
            // create filter
            Crop cropStone = new Crop(new Rectangle(2, 165, 115, 80));
            // apply the filter
            Bitmap cropedImageStone = cropStone.Apply((Bitmap)picImage.Image);
            picCropStone.Image = cropedImageStone;

            

              
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (picImage.Image != null)
            {
                picImage.Image.Save(@"D:\Test.jpg", ImageFormat.Jpeg);
            }
            if (pictureBox1.Image != null)
            {
                pictureBox1.Image.Save(@"D:\TestN.jpg", ImageFormat.Jpeg);
            }
            else
            {
                MessageBox.Show("Picture Box is empty!!!!");
            }
        }
    }
}
